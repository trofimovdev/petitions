self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6bc937533a243de490104b3e03d8b2cd",
    "url": "./index.html"
  },
  {
    "revision": "f80fa49f22732c78f152",
    "url": "./static/css/2.aeb34ba9.chunk.css"
  },
  {
    "revision": "97f9dfb7e218516b9b25",
    "url": "./static/css/main.3b800296.chunk.css"
  },
  {
    "revision": "f80fa49f22732c78f152",
    "url": "./static/js/2.011fd2c6.chunk.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "./static/js/2.011fd2c6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "97f9dfb7e218516b9b25",
    "url": "./static/js/main.95ac6f75.chunk.js"
  },
  {
    "revision": "cd88e963c3fa7def7957",
    "url": "./static/js/runtime-main.254d1be6.js"
  }
]);